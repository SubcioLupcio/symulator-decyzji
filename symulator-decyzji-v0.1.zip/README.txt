Symulator Decyzji – wersja 0.1 (statyczna)
============================================

Pliki:
- index.html — cała gra (Phaser 3, wybór postaci, statystyki, progi zwycięstwa/porażki).
- scenarios.json — treść scenariuszy (możesz edytować bez grzebania w kodzie).

Jak uruchomić na dowolnym hostingu statycznym (GitHub Pages, Netlify, serwer www):
1) Wgraj oba pliki do tego samego katalogu.
2) Wejdź na adres /index.html (GitHub Pages: https://twoj_user.github.io/twoje-repo/).
3) Jeśli nie widzisz zmian, do adresu dodaj ?v=0.1 i odśwież (Ctrl+F5).

Edytowanie scenariusza:
- Otwórz scenarios.json i dodaj/zmień węzły.
- Uważaj na przecinki i cudzysłowy (musi to być poprawny JSON).

Licencja: MIT (do swobodnego użycia i modyfikacji).
